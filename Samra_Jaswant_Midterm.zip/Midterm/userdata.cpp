#include "userdata.h"
#include <QList>
#include <eventregistration.h>

userData::userData()
{

