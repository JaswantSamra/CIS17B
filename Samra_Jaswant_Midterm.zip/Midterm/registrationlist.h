#ifndef REGISTRATIONLIST_H
#define REGISTRATIONLIST_H


class registrationList
{
public:
    registrationList();
};

#endif // REGISTRATIONLIST_H
