#ifndef USERDATA_H
#define USERDATA_H
#include <eventregistration.h>

class userData
{
public:
    userData();
};

#endif // USERDATA_H
