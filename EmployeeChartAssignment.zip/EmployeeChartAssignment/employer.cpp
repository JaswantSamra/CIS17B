#include "employer.h"
#include <iostream>
using namespace std;

void Employer::hire(Person* newHire, Position * pos)
{
    newHire->setEmployer(this);
    newHire->setPosition(pos);
    employees.push_back(newHire);
}

void Employer::printEmployees()
{
    if(employees.size() > 0)
    {
        int j = employees.size();
        for(int i = 0; i < j; i++)
        {
           cout << "1. ";
           cout << employees[i]->toString();
           cout << endl;
        }
    }
}

Employer::Employer(string name, string market)
{
    m_Name = name;
    m_Market = market;
}

string Employer::toString()
{
    return "Employer: " + m_Name + "\nMarket: " + m_Market;
}


