#include "position.h"

Position::Position(string name, string description)
{
    this->m_Name = name;
    this->m_Description = description;
}

string Position::toString()
{
    return "Position: " + m_Name + "\nDescription: " + m_Description;
}
