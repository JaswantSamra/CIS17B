#include <QCoreApplication>
#include "person.h"
#include "position.h"
#include "employer.h"
#include <iostream>
using namespace std;

class Person;
class Position;
class Employer;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Employer employer0("StarFleet Federation", "Fightin Stuff"), employer1("Borg", "Attack them");
    Person person1("Jean-Luc Picard"), person2("Wesley Crusher"), person3("Anakin Skywalker");
    Position pos1("Star Captain", "Captain of the fleet"), pos2("Cyborg", "Cyborg Captain"), pos3("Admiral", "Admiral of the fleet");

    employer0.hire(&person1,&pos1);
    employer0.hire(&person3,&pos3);
    employer1.hire(&person2,&pos2);

    employer0.printEmployees();

    return a.exec();
}
