#ifndef EMPLOYER_H
#define EMPLOYER_H
#include <string>
#include <vector>
#include "person.h"
#include "position.h"
using namespace std;

class Person;
class Position;

class Employer
{
private:
    string m_Name;
    string m_Market;
    vector<Person*> employees;

public:
    void hire(Person* newHire, Position*pos);
    void printEmployees();
    Employer(string name, string market);
    string toString();
};

#endif // EMPLOYER_H
